import { useContext } from "react";
import { ProductData } from "./App";
import Product from "./Product";

const SearchProduct = ({ query }) => {
  let products = useContext(ProductData);

  products = products.filter((prod) =>
    prod.title.toLowerCase().includes(query)
  );

  const searchResult = products.map((item) => {
    return (
      <>
        <Product
          id={item?.id}
          title={item?.title}
          price={item?.price}
          rating={item?.rating}
          image={item?.image}
        />
        
      </>
    );
  });

  return (
    <>
      <div>{searchResult}</div>
    </>
  );
};

export default SearchProduct;
