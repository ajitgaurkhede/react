import { useContext } from "react";
import { ProductData } from "./App";
import "./Home.css";
import Product from "./Product";
import "./Product.css";

const Home = () => {
  const allProducts = useContext(ProductData);
  const renderAllProducts = allProducts.map((item) => {
    return (
      <>
        <Product
          id={item?.id}
          title={item?.title}
          price={item?.price}
          rating={item?.rating}
          image={item?.image}
        />
      </>
    );
  });

  return (
    <>
      <div className="home">
        <img
          className="home_image"
          src="https://images-eu.ssl-images-amazon.com/images/G/31/img18/PCA/Gateway/CatCard/PC_Hero_VG_BAU_Consoles_Apr1st-week_2x._CB593240485_.jpg"
          alt="hey"
        />
        <div className="home_row">{renderAllProducts}</div>
      </div>
    </>
  );
};

export default Home;
