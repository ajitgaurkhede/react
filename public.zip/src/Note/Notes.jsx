import { useFormik } from "formik";
import NoteService from "../Services/NoteService/NoteService";

const Notes = () => {
  const initValues = {
    title: "",
    noteContent: "",
  };

  const { values, handleChange, handleSubmit } = useFormik({
    initialValues: initValues,
    onSubmit: (values) => {
      console.log(values);
      NoteService.saveNotes(values)
        .then((res) => {
            alert(res.data)
        })
        .catch((err) => {
          alert(err);
        });
    },
  });

  return (
    <>
      <div className="container">
        <h3>please fill your note details</h3>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label for="exampleInputEmail1">enter note title</label>
            <input
              type="text"
              className="form-control"
              id="exampleInputEmail1"
              aria-describedby="emailHelp"
              placeholder="Enter note"
              name="title"
              onChange={handleChange}
              value={values.title}
            />
          </div>
          <div className="form-group">
            <label for="exampleFormControlTextarea1">Note Content</label>
            <textarea
              className="form-control"
              id="exampleFormControlTextarea1"
              rows="3"
              name="noteContent"
              onChange={handleChange}
              value={values.noteContent}
            ></textarea>
          </div>
          <br></br>
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </form>
      </div>
    </>
  );
};

export default Notes;
