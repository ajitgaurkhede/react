import { useReducer } from "react";

const initialState = 0;

const reducer = (state, action) => {
  console.log(state, action);
  switch (action.type) {
    case "INCREMENT":
      return state + 1;

    case "DECREMENT":
      return state - 1;

    default:
      return state;
  }

  return state;
};

const MyReducer = () => {
  const [state, dispatch] = useReducer(reducer, initialState);
  return (
    <>
      <p>{state}</p>
      <div>
        <button onClick={() => dispatch({ type: "INCREMENT" })}>Inc</button>
        <button onClick={() => dispatch({ type: "DECREMENT" })}>Dec</button>
      </div>
    </>
  );
};
export default MyReducer;
