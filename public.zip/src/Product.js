import { useReducer } from "react";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './Product.css';
import reducer, { initialState } from "./reducer";


const Product = ({ id, title, image, price, rating }) => {

   // const [{basket}, dispatch] = useStateValue();

   const [,dispatch] = useReducer(reducer,initialState);

const addToBasket =()=>{
    dispatch({
        type: 'ADD_TO_BASKET',
        item:{
            id: id,
            title: title,
            image: image,
            price: price,
            rating: rating,
        },
    });
    
};

    return (
        <> 
        <div className='product' key={id}>
            <div className='product_info'>
            <p>{title}</p>
            <p className='product_price'>
                <small>RS </small>
                <strong>{price}</strong>
            </p>
            </div>
            <img src={image} alt="" />
            <button onClick={addToBasket}>Add to basket</button>
            
        </div>
        <ToastContainer />
        </>
    )


}

export default Product;