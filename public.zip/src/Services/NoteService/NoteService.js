import axios from "axios";
import baseUrl from "../BaseUrl";

const NoteService = {
  saveNotes: async (data) => {
    return await axios.post(`${baseUrl}/saveNote`, data);
  },
};

export default NoteService;
