import axios from "axios";
import baseUrl from "../BaseUrl";

const ProductService = {
  addProduct: async (product) => {
    return await axios.post(`${baseUrl}/products`, product);
  },

  getAllProduct: async () => {
    return await axios.get(`${baseUrl}/products`);
  },

  addToBasket: async (basket) => {
    return await axios.post(`${baseUrl}/addToBasket`, basket);
  },

  getBasket: async () => {
    return await axios.get(`${baseUrl}/basket`);
  },
  deletFromBasket: async (id) =>{
    return await axios.delete(`${baseUrl}/deleteFromBasket/${id}`);
  },
};

export default ProductService;
