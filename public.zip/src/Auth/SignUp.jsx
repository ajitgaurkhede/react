import { useFormik } from "formik";
import * as Yup from "yup";

const SignUp = () => {

const initValues ={

  password: "",
  email: "",

}

  const { values, errors, handleBlur, handleChange, handleSubmit } = useFormik({

    initialValues:initValues,
    onSubmit:{
      
    }
    

  })

  return (
    <>
      <div className="container">
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label for="exampleInputEmail1" classNameName="form-label">
              Email address
            </label>
            <input
              type="email"
              className="form-control"
              id="exampleInputEmail1"
              aria-describedby="emailHelp"
              name = "email"
              value={values.email}
            onChange={handleChange}
            onBlur={handleBlur}
            error={errors.email}
            helperText={errors.email}
            />
          </div>
          <div className="mb-3">
            <label for="exampleInputPassword1" className="form-label">
              Password
            </label>
            <input
              type="password"
              className="form-control"
              id="exampleInputPassword1"
              name="password"
            />
          </div>
          <button type="submit" className="btn btn-primary">
            Sign Up
          </button>
        </form>
      </div>
    </>
  );
};

export default SignUp;
