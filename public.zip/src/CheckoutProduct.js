import { useReducer } from "react";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import reducer, { initialState } from "./reducer";



const CheckoutProduct = ({ id, title, image, price, rating }) => {
  //const [,dispatch] = useStateValue();

  const [,dispatch] = useReducer(reducer,initialState);

  const removeFromBasket = () => {
    // remove item from basket..
    dispatch({
      type: "REMOVE_FROM_BASKET",
        id: id,
    });
   
  };

  return (
    <>
      <div className="checkoutProduct">
        <img className="checkoutProduct_img" src={image} alt="hey" />

        <div className="checkoutProduct_info">
          <p className="checkoutProduct_title">{title}</p>
          <p className="checkoutProduct_price">
            <small>RS </small>
            <strong>{price}</strong>
          </p>
          <button onClick={removeFromBasket}>Remove from Basket</button>
        </div>
      </div>
      <ToastContainer />
    </>
  );
};

export default CheckoutProduct;
