import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import ProductService from "./Services/Product/ProductService";

export const initialState = {
 basket:[]
};

const reducer = (state, action) => {
  const newState ={...state}
  switch (action.type) {
    case "ADD_TO_BASKET":
      ProductService.addToBasket(action.item)
        .then((res) => {
          newState.basket.push(action.item)

        })
        .catch((err) => {
          alert(err);
        });
      break;
    case "REMOVE_FROM_BASKET":
      ProductService.deletFromBasket(action.id)
        .then((res) => {
          newState.basket = newState.basket.filter(item => item.id !== action.id)
          
          toast.success("Product Removed From Basket",{position: "bottom-left",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "colored",});
        })
        .catch((err) => {
          alert(err);
        });

     break;
    default:
      return state;
  }
  return newState;
};

export default reducer;
