import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import "./App.css";
import Header from "./Header";
import Home from "./Home";
import Checkout from "./Checkout";
import AddProduct from "./AddProduct";
import { createContext } from "react";
import ProductService from "./Services/Product/ProductService";
import { useEffect, useState } from "react";
import SearchProduct from "./SearchProduct";
import SignIn from "./Auth/SignIn";
import SignUp from "./Auth/SignUp";
import Notes from "./Note/Notes";

const ProductData = createContext();
const BasketData = createContext();

function App() {
  const [allProducts, setAllProducts] = useState([]);
  const [basket, setBasket] = useState([]);
  useEffect(() => {
    getAllProducts();
    getBasket();
  }, []);

  const getBasket = () => {
    ProductService.getBasket()
      .then((res) => {
        setBasket(res?.data);
      })
      .catch((err) => {
        alert(err);
      });
  };

  const getAllProducts = () => {
    ProductService.getAllProduct()
      .then((res) => {
        setAllProducts(res?.data);
      })
      .catch((err) => {
        alert(err);
      });
  };

  return (
    <Router>
      <div className="app">
        <ProductData.Provider value={allProducts}>
          <BasketData.Provider value={basket}>
            <Header />
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/checkout" element={<Checkout />} />
              <Route path="/addproduct" element={<AddProduct />} />
              <Route path="/searchproduct" element={<SearchProduct />} /> 
              <Route path="/login" element={<SignIn />} /> 
              <Route path="/signup" element={<SignUp />} /> 
              <Route path="/notes" element={<Notes />} /> 
            </Routes>
          </BasketData.Provider>
        </ProductData.Provider>
      </div>
    </Router>
  );
}

export default App;
export { ProductData, BasketData };
