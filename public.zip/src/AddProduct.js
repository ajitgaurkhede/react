import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import { useFormik } from "formik";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import * as Yup from "yup";
import ProductService from "./Services/Product/ProductService";

const AddProduct = () => {
  const initialValues = {
    title: "",
    image: "",
    price: "",
    rating: "",
  };

  const { values, errors, handleBlur, handleChange, handleSubmit } = useFormik({
    initialValues: initialValues,
    onSubmit: (values) => {
      console.log(values);
      ProductService.addProduct(values).then((res)=>{
       // alert("success added")
       toast("Product Added");
        
      })
      .catch((err)=>{
          alert(err)
      })

    },
    validationSchema : Yup.object({
      title: Yup.string().required("Please Enter the Title"),
      image: Yup.string().required("Please Enter the Title"),
      price: Yup.number().required(),
      rating: Yup.number().required()

    })


  });

  return (
    <>
      <div className="container">
        <form onSubmit={handleSubmit}>
          <TextField
            id="standard-basic"
            label="title"
            variant="standard"
            name="title"
            value={values.title}
            onChange={handleChange}
            onBlur={handleBlur}
            error={errors.title}
            helperText={errors.title}
          />
          <TextField
            id="standard-basic"
            label="image"
            variant="standard"
            name="image"
            value={values.image}
            onChange={handleChange}
            onBlur={handleBlur}
            error={errors.image}
            helperText={errors.image}
          />
          <TextField
            id="standard-basic"
            label="price"
            variant="standard"
            name="price"
            value={values.price}
            onChange={handleChange}
            onBlur={handleBlur}
            error={errors.price}
            helperText={errors.price}
          />
          <TextField
            id="standard-basic"
            label="rating"
            variant="standard"
            name="rating"
            value={values.rating}
            onChange={handleChange}
            onBlur={handleBlur}
            error={errors.rating}
            helperText={errors.rating}
          />
          <Button variant="outlined" type="submit">
            Add Product
          </Button>
        </form>
      </div>
    </>
  );
};

export default AddProduct;
