import SearchIcon from "@mui/icons-material/Search"
import ShoppingBasketIcon from "@mui/icons-material/ShoppingBasket"
import { useContext, useState } from "react"
import { Link } from "react-router-dom"
import { BasketData } from "./App"
import "./Header.css"
import SearchProduct from "./SearchProduct"

const Header = () => {

    const basket = useContext(BasketData);
    const [query,setQuery] = useState();

    return (
        <>
            <nav className="header">
                <Link to="/">
                    <img className="header_logo" src="https://i0.wp.com/www.alphr.com/wp-content/uploads/2019/12/Amazon-Keeps-Logging-Me-Out-What-to-Do.jpg?fit=1000%2C563&ssl=1"
                        alt="hey"></img>
                </Link>
                {/*search box */}
                <div className="header_search">
                    <input type="text" className="header_search_input" onChange={(e)=> setQuery(e.target.value)}></input>
                </div>
                <SearchIcon className="header_search_icon" />

                <div className="header_nav">
                    <Link to="/" className="header_link">
                        <div className="header_option">
                            <span className="header_optionLineOne">Hello Ajit</span>
                            <span className="header_optionLineTwo">Sign In</span>
                        </div>

                    </Link>

                    <Link to="/" className="header_link">
                        <div className="header_option">
                            <span className="header_optionLineOne">Returns</span>
                            <span className="header_optionLineTwo">& Orders</span>
                        </div>

                    </Link>

                    <Link to="/" className="header_link">
                        <div className="header_option">
                            <span className="header_optionLineOne">Your</span>
                            <span className="header_optionLineTwo">Prime</span>
                        </div>

                    </Link>

                    {/* 4th lin */}

                    <Link to ="/checkout" className="header_link">
                        <div className="header_optionBasket">
                        <ShoppingBasketIcon />
                            <span className="header_optionLineTwo header_basketCount">{basket?.length}</span>
                            
                        </div>
                    
                    </Link>

                </div>

            </nav>
            <SearchProduct query={query} />

        </>
    )

}

export default Header;