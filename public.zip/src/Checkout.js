import { useContext } from "react";
import { BasketData } from "./App";
import "./Checkout.css";
import CheckoutProduct from "./CheckoutProduct";


const Checkout = () => {

 const basket = useContext(BasketData);

  return (
    <>
      <div className="checkout">
        <img
          className="checkout_img"
          src="https://images-eu.ssl-images-amazon.com/images/G/31/img19/AmazonPay/Pay_Balance/apay_pc_banner_2.jpg"
          alt="hey"
        />
        {basket?.length === 0 ? (
          <div>
            <h2>Your Shopping Basket is empty</h2>
            <p>
              You have no items in your basket. To buy one or "Add to basket"
              next to the item.
            </p>
          </div>
        ) : (
          <div>
            <h2 className="checkout_title">Your Shopping Basket</h2>
            {/* checkout products */}
            {basket.map( item =>(
                 <CheckoutProduct 
                 id = {item.id}
                 title={item.title}
                 image ={item.image}
                 price={item.price}
                 rating={item.rating}
                 />

            )

            )}
           
          </div>
        )}
      </div>
      {basket.length > 0 && (
        <div className="checkout_right">
          <h1>checkout right</h1>
        </div>
      )}
    </>
  );
};

export default Checkout;
