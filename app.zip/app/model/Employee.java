package com.dell.empmsystem.app.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

import jakarta.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "employees")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "fullName")
    private String fullName;

    @Column(name = "email_id")
    private String emailId;

    @Column(name = "age")
    private int age;

    @Column(name = "gender")
    private String gender;

    
    @Column(name = "address")
    private String adress;

        
    @Column(name = "DOB")
    private Date DOB;

    @Column(name = "department")
    private String department;

    
    @Column(name = "designation")
    private String designation;

    @Column(name = "mobile")
    private String mobile;

    


}