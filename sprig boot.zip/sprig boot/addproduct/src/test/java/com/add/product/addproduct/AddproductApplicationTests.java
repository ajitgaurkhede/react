package com.add.product.addproduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddproductApplicationTests {

	@Test
	void contextLoads() {
	}

}
