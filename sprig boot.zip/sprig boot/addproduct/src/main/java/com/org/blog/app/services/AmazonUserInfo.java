package com.org.blog.app.services;

import com.org.blog.app.dto.AmazonUserDto;

public interface AmazonUserInfo {
    AmazonUserDto savAmazonUserInfo(AmazonUserDto amazonUser);
    AmazonUserDto getAmazonUserInfo(Long id);

}
