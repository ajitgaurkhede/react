package com.org.blog.app.doa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.org.blog.app.entities.UserInfo;

import java.util.Optional;

public interface UserInfoRepo extends JpaRepository<UserInfo, Integer> {
    Optional<UserInfo> findByName(String username);

}