package com.org.blog.app.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;
/* 
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.org.blog.app.doa.UserInfoRepo;
import com.org.blog.app.doa.UserRepo;
import com.org.blog.app.dto.UserDto;
import com.org.blog.app.entities.User;
import com.org.blog.app.entities.UserInfo;
import com.org.blog.app.exceptions.ResourceNotFoundException;
import com.org.blog.app.services.UserService;

@Component
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private UserInfoRepo userInfoRepo;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public UserDto createUser(UserDto userDto) {

        User user = dtoToUser(userDto);
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userToDto(userRepo.save(user));
    }

    @Override
    public UserDto updateUser(UserDto userDto, Integer userId) {
        // userRepo.findById(userId).orElseThrow(()-> new
        // ResourceNotFoundException("User","id", userId));

        User user = userRepo.findById(userId).orElseThrow(ResourceNotFoundException::new);

        user.setAbout(userDto.getAbout());
        user.setEmail(userDto.getEmail());
        user.setName(userDto.getName());
        user.setPassword(userDto.getPassword());

        return userToDto(userRepo.save(user));
    }

    @Override
    public UserDto getUserById(Integer userId) {
        User user = userRepo.findById(userId).orElseThrow(ResourceNotFoundException::new);
        return userToDto(user);
    }

    @Override
    public List<UserDto> getAllUsers() {
        List<User> users = userRepo.findAll();
        List<UserDto> userDtos = users.stream().map(user -> userToDto(user)).collect(Collectors.toList());
        return userDtos;
    }

    @Override
    public void deleteUser(Integer userId) {
        User user = userRepo.findById(userId).orElseThrow(ResourceNotFoundException::new);
        userRepo.delete(user);
    }

    private User dtoToUser(UserDto userDto) {
        User user = modelMapper.map(userDto, User.class);
        user.setId(userDto.getId());
        user.setAbout(userDto.getAbout());
        user.setEmail(userDto.getEmail());
        user.setName(userDto.getName());
        user.setPassword(userDto.getPassword());
        return user;
    }

    private UserDto userToDto(User user) {
        UserDto userDto = modelMapper.map(user, UserDto.class);
       userDto.setId(user.getId());
        userDto.setAbout(user.getAbout());
        userDto.setEmail(user.getEmail());
        userDto.setName(user.getName());
        userDto.setPassword(user.getPassword());
        return userDto;

    }

    public String addUser(UserInfo userInfo) {
        userInfo.setPassword(passwordEncoder.encode(userInfo.getPassword()));
        userInfoRepo.save(userInfo);
        return "user added to system ";
    }

}
*/