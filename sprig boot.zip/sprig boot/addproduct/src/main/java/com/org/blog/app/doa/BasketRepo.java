package com.org.blog.app.doa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.org.blog.app.entities.Basket;

public interface BasketRepo extends JpaRepository<Basket,Integer> {
    
}
