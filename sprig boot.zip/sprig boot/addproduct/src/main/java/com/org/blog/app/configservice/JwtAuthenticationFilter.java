package com.org.blog.app.configservice;
/* 
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private JwtTokenHelper jwtTokenHelper;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        // 1. get token

        String requestToken = request.getHeader("Authorization");

        // we get Bearer token

        System.out.println(requestToken);

        //String username = null;
        String token = null;

        if (requestToken != null && requestToken.startsWith("Bearer")) {
            try {
                token = requestToken.substring(7);
                this.jwtTokenHelper.getUserNameFromToken(token);
            } catch (Exception ex) {

                ex.printStackTrace();

            }
        } else {
            System.out.println("not valid bearer token");
        }

        System.out.println("username is null");
        filterChain.doFilter(request, response);
    }

}*/
