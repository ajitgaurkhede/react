package com.org.blog.app.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.org.blog.app.doa.ProductRepo;
import com.org.blog.app.entities.Basket;
import com.org.blog.app.entities.Product;

import jakarta.transaction.Transactional;

@Component
public class ProductService {

    @Autowired
    private ProductRepo productRepo;
    @Autowired
    private com.org.blog.app.doa.BasketRepo basketRepo;

   // @Transactional
    public List<Product> getAllProducts() {
        return productRepo.findAll();
    }

    //@Transactional
    public Product addProduct(Product product) {
        return productRepo.save(product);
    }

   // @Transactional
    public Basket addToBasket(Basket basket) {
        return basketRepo.save(basket);
    }

   // @Transactional
    public List<Basket> getBasket(){
        return basketRepo.findAll();
    }

    @Transactional
    public void deletFromBasket(Integer id){
        basketRepo.deleteById(id);
    }

}
