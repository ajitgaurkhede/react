package com.org.blog.app.serviceImpl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.org.blog.app.doa.AmazonUserInfoRepo;
import com.org.blog.app.dto.AmazonUserDto;
import com.org.blog.app.services.AmazonUserInfo;
import com.org.blog.app.entities.AmazonUser;

@Component
public class AmazonUserInfoImpl implements AmazonUserInfo {

    @Autowired
    private AmazonUserInfoRepo repo;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public AmazonUserDto savAmazonUserInfo(AmazonUserDto amazonUser) {
        AmazonUser aUser = this.dtoToAmazonUser(amazonUser);
        return this.AmazonUserToDto(repo.save(aUser));
    }

    @Override
    public AmazonUserDto getAmazonUserInfo(Long id) {
        AmazonUser aUser = repo.findById(id).get();
        return this.AmazonUserToDto(aUser);

    }

    public AmazonUser dtoToAmazonUser(AmazonUserDto dto) {
        AmazonUser amazonUser = modelMapper.map(dto, AmazonUser.class);
        return amazonUser;
    }

    public AmazonUserDto AmazonUserToDto(AmazonUser amazonUser) {
        AmazonUserDto dto = modelMapper.map(amazonUser, AmazonUserDto.class);
        return dto;

    }

}
