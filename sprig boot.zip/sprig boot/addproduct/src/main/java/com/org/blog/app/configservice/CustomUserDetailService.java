package com.org.blog.app.configservice;

import java.util.Optional;
/* 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.org.blog.app.config.UserDetailService;
import com.org.blog.app.doa.UserInfoRepo;
import com.org.blog.app.entities.UserInfo;

@Component
public class CustomUserDetailService implements UserDetailsService {

    @Autowired
    private UserInfoRepo userInfoRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<UserInfo> userInfo = userInfoRepo.findByName(username);
        return userInfo.map(UserDetailService::new)
                .orElseThrow(() -> new UsernameNotFoundException("user not found " + username));

    }
    
}*/
