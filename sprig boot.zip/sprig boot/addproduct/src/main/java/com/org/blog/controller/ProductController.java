package com.org.blog.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.org.blog.app.dto.AmazonUserDto;
import com.org.blog.app.entities.Basket;
import com.org.blog.app.entities.Note;
import com.org.blog.app.entities.Product;
import com.org.blog.app.serviceImpl.AmazonUserInfoImpl;
import com.org.blog.app.serviceImpl.NoteService;
import com.org.blog.app.services.ProductService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class ProductController {

    @Autowired
    private ProductService productService;

    @Autowired
    private AmazonUserInfoImpl amazonUserService;

    @Autowired
    private NoteService noteService;

    @PostMapping("/addProduct")
    public Product addProduct(@RequestBody Product product){
        return productService.addProduct(product) ;
        
    }

    @GetMapping("/products")
    //@PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public List<Product> getAllProducts(){
        return productService.getAllProducts();
        
    }

    @PostMapping("/addToBasket")
    public Basket addToBasket(@RequestBody Basket basket){
    return productService.addToBasket(basket);
    }

    @GetMapping("/basket")
    public List<Basket> getBasket(){
        return productService.getBasket();
    }

    @DeleteMapping("/deleteFromBasket/{id}")
    public String deletFromBasket(@PathVariable("id") Integer id){
        productService.deletFromBasket(id);
        return "Success";
    }

    @PostMapping("/saveInfo")
    public AmazonUserDto saveAmazonUserInfo(@RequestBody AmazonUserDto amazonUserDto){
        return this.amazonUserService.savAmazonUserInfo(amazonUserDto);
    }

    @GetMapping("/getInfo/{id}")
    public AmazonUserDto getAmazonUserInfo(@PathVariable Long id){
        return this.amazonUserService.getAmazonUserInfo(id);
    }

    @PostMapping("/saveNote")
    public String saveNotes(@RequestBody Note note){
        return this.noteService.saveNotes(note);
    }

    
    
}
