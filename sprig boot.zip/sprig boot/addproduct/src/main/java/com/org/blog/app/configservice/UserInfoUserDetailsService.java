package com.org.blog.app.configservice;
/* 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.org.blog.app.doa.UserRepo;
import com.org.blog.app.entities.User;
import com.org.blog.app.exceptions.ResourceNotFoundException;

@Component
public class UserInfoUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepo userRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User userInfo = userRepo.findByEmail(username).orElseThrow(ResourceNotFoundException::new);
        return userInfo;
    }
    
}
*/