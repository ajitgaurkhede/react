package com.org.blog.app.services;

  interface Test {

    int a = 0;

    void dj();

    
}
