package com.org.blog.app.dto;

import com.org.blog.app.entities.Address;

import lombok.Data;

@Data
public class AmazonUserDto {

    private Long id;
    private String name;
    private String lastName;
    private Address address;
    
}
