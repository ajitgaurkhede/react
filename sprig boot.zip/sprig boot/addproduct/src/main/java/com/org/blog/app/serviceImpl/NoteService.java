package com.org.blog.app.serviceImpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.org.blog.app.entities.Note;
import com.org.blog.app.helper.FactoryProvider;

@Repository
public class NoteService {

    public String saveNotes(Note note) {
        SessionFactory factory = FactoryProvider.getFactory();
        Session session = factory.openSession();

        Transaction tx = session.beginTransaction();

        session.persist(note);

        tx.commit();

        return "saved";
    }

}
