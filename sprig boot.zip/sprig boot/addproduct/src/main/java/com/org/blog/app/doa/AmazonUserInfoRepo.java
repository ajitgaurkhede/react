package com.org.blog.app.doa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.org.blog.app.entities.AmazonUser;

public interface AmazonUserInfoRepo extends JpaRepository<AmazonUser, Long>{


}
