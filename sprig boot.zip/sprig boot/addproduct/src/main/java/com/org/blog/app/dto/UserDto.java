package com.org.blog.app.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
public class UserDto {

    private int id;
    @NotEmpty
    @Size(min = 4, message = "username must be min 4 char")
    private String name;
    @Email(message = "invalid mail")
    private String email;
    @NotNull
    private String password;
    @NotNull
    private String about;
    
}
